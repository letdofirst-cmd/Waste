# EcoSmart Waste (SIH 2026, PS 26195)
Student Innovation: waste segregation, disposal and sanitation. Category: Software. Theme: Clean & Green Technology.

## What's inside
- `frontend/index.html` - working prototype (citizen + admin views). Open in any browser; no install. Data is saved in the browser only.
- `backend/` - FastAPI + SQLite API: reports, heatmap, pickups, notifications, rewards.
- `database/schema.sql` - schema (loaded automatically by the backend).
- `docs/SIH_PRESENTATION.md` - problem, solution, PPT outline, roadmap, team roles, jury Q&A.

## Run the backend
```
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```
Open http://127.0.0.1:8000/docs to try every endpoint.

## Status (be honest with judges)
- Frontend prototype: working, standalone.
- Backend API: written, not yet wired to the frontend (next step: replace the in-browser state with fetch() calls to these endpoints).
- Not built yet: AI photo classifier (guide uses keyword lookup), real map tiles, login.
